<?php

namespace WMAIGEN\Infrastructure;

/**
 * Option-backed plugin settings storage.
 */
final class SettingsRepository {
	public const OPTION_NAME = 'wmaigen_settings';

	/**
	 * @return array<string, mixed>
	 */
	public function get(): array {
		$stored = get_option( self::OPTION_NAME, array() );

		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		return wp_parse_args( $stored, $this->get_defaults() );
	}

	/**
	 * @param array<string, mixed> $raw_settings Settings from the request.
	 * @return array<string, mixed>
	 */
	public function update( array $raw_settings ): array {
		$sanitized = $this->sanitize( $raw_settings );
		update_option( self::OPTION_NAME, $sanitized, false );

		return $sanitized;
	}

	/**
	 * @param array<string, mixed>|null $settings Settings override.
	 */
	public function is_configured( ?array $settings = null ): bool {
		$current = is_array( $settings ) ? $settings : $this->get();

		return '' !== $current['base_url'] && '' !== $current['api_key'] && '' !== $current['model'];
	}

	/**
	 * @param array<string, mixed> $raw_settings Untrusted settings input.
	 * @return array<string, mixed>
	 */
	public function sanitize( array $raw_settings ): array {
		$defaults = $this->get_defaults();
		$settings = wp_parse_args( $raw_settings, $defaults );

		$base_url = esc_url_raw( trim( (string) wp_unslash( $settings['base_url'] ) ) );
		$base_url = rtrim( $base_url, '/' );

		if ( $this->ends_with( $base_url, '/chat/completions' ) ) {
			$base_url = substr( $base_url, 0, - strlen( '/chat/completions' ) );
		}

		return array(
			'base_url'         => $base_url,
			'api_key'          => sanitize_text_field( (string) wp_unslash( $settings['api_key'] ) ),
			'model'            => sanitize_text_field( (string) wp_unslash( $settings['model'] ) ),
			'timeout'          => $this->normalize_timeout( $settings['timeout'] ),
			'dry_run'          => empty( $settings['dry_run'] ) ? 0 : 1,
			'prompt_post_like' => sanitize_textarea_field( (string) wp_unslash( $settings['prompt_post_like'] ) ),
			'prompt_term_like' => sanitize_textarea_field( (string) wp_unslash( $settings['prompt_term_like'] ) ),
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	public function get_defaults(): array {
		return array(
			'base_url'         => 'https://api.openai.com/v1',
			'api_key'          => '',
			'model'            => '',
			'timeout'          => 30,
			'dry_run'          => 1,
			'prompt_post_like' => 'You write clear WordPress excerpts. Return one complete sentence in plain text. Keep it moderate in length, do not copy the opening paragraph verbatim, and avoid truncated fragments or title-like stubs.',
			'prompt_term_like' => 'You write clear taxonomy descriptions for WordPress. Return one complete sentence in plain text. Keep it moderate in length, do not copy existing text verbatim, and avoid truncated fragments.',
		);
	}

	/**
	 * @param mixed $timeout Raw timeout input.
	 */
	private function normalize_timeout( $timeout ): int {
		$value = absint( $timeout );

		if ( $value < 5 ) {
			$value = 5;
		}

		if ( $value > 120 ) {
			$value = 120;
		}

		return $value;
	}

	private function ends_with( string $haystack, string $needle ): bool {
		if ( '' === $needle ) {
			return true;
		}

		return substr( $haystack, - strlen( $needle ) ) === $needle;
	}
}
