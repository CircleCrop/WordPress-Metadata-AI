<?php
/**
 * Post editor meta box template.
 *
 * @var \WP_Post $post
 * @var bool     $dry_run
 */
?>
<?php wp_nonce_field( 'wmaigen_generate_post', 'wmaigen_generate_post_nonce' ); ?>
<p>
	<?php if ( $dry_run ) : ?>
		<strong><?php esc_html_e( 'Dry Run is enabled.', 'wordpress-metadata-aigen' ); ?></strong>
		<?php esc_html_e( 'The generated description will be previewed in an admin notice and not written to the excerpt field.', 'wordpress-metadata-aigen' ); ?>
	<?php else : ?>
		<?php esc_html_e( 'Generate a description and write it to the standard WordPress excerpt field.', 'wordpress-metadata-aigen' ); ?>
	<?php endif; ?>
</p>
<?php if ( '' !== trim( (string) $post->post_excerpt ) ) : ?>
	<p><strong><?php esc_html_e( 'Current excerpt:', 'wordpress-metadata-aigen' ); ?></strong> <?php echo esc_html( $post->post_excerpt ); ?></p>
<?php else : ?>
	<p><?php esc_html_e( 'Current excerpt is empty.', 'wordpress-metadata-aigen' ); ?></p>
<?php endif; ?>
<p>
	<label for="wmaigen-overwrite-existing-post">
		<input id="wmaigen-overwrite-existing-post" type="checkbox" name="wmaigen_overwrite_existing" value="1">
		<?php esc_html_e( 'Overwrite existing excerpt', 'wordpress-metadata-aigen' ); ?>
	</label>
</p>
<p>
	<button type="submit" class="button button-secondary" name="wmaigen_generate_post" value="1">
		<?php esc_html_e( 'Save and Generate Description', 'wordpress-metadata-aigen' ); ?>
	</button>
</p>
<p class="description">
	<?php esc_html_e( 'This button submits the normal editor form first, then runs generation. Any other post changes on the screen will also be saved.', 'wordpress-metadata-aigen' ); ?>
</p>
